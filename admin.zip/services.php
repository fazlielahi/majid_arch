<?php
  session_start();
  include("inc/database.php");
  include("inc/functions.php");
  $category_id = (isset($_GET['id'])) ? $_GET['id'] : 1;
  $service_categ = getservices_categ($category_id);
  //print_r($services);
  $service_categ_container = "";
 
    //$active = ($index === 0) ? "active" : "";
    $slug = strtolower($service_categ['title']); //die($slug);
    $service_categ_container .= "
    
                                <div id='$slug' class='tab-content active'>
                                    <div class='content-container'>
                                      <img src='images/banner-main-page.jpg' alt='$service_categ[title]'>
                                      <div class='text-content'>
                                        <h3>$service_categ[title]</h3>
                                        <p>
                                          $service_categ[description]
                                        </p>
                                    </div>
                                  </div>
                                ";

                              echo $service_categ['id'];  
  $services = get_services("category_services", $service_categ['id']);
  $services_cards = "";
      foreach($services as $service){

        $services_cards .= "

                      <div class='service-card' data-service-id='1'>
                        <div class='service-icon'><i class='fas fa-drafting-compass'></i></div>
                        <h3>$service[title]</h3>
                        <p>$service[text]</p>
                      </div>
                      ";

      }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Our Professional Services</title>
  <link rel="stylesheet" href="styles/header-footer.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/services.css">
  
  <style>
  
  </style>
</head>
<body>

  <?php include("inc/header.php") ?>

  
  <div class="services-tabs">
    <?php echo "<a href='services.php?id=" . 1 . "' class='tab-btn services-btn' data-tab='architecture design'>Architecture Design</a>
    <a href='services.php?id=" . 2 . "' class='tab-btn services-btn' data-tab='interior design'>Interior Design</a>"
     ?>
  </div>
  
    <?php
      // displaying services category headings
      echo $service_categ_container 
     ?>
  
  <section class='services'>
    <?php
      // displaying services
      echo $services_cards 
     ?>
    </section>
      <!-- Modal Overlay for Service Details -->
      <div id="modalOverlay" class="modal-overlay">
        <div class="modal-container">
          <span class="modal-close" id="modalClose">&times;</span>
          <div class="modal-content" id="modalContent">
            <!-- Dynamic content inserted via JS -->
          </div>
        </div>
      </div>
      
  </div>
  
  
  <footer>
    <p>&copy; 2025 Mian Majid Khan Architecture. All rights reserved.</p>
  </footer>

  <script>
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    // Remove active class from all buttons and tab contents
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));

    // Activate the clicked button
    this.classList.add('active');
    
    // Get the associated content container
    const tabId = this.getAttribute('data-tab');
    const contentContainer = document.getElementById(tabId);

    if (contentContainer) {
      contentContainer.classList.add('active');
    } else {
      console.error(`No content container found with id: ${tabId}`);
    }
  });
});



    // Sample data for service details (can be replaced with dynamic content)
const serviceDetails = {
  1: {
    title: 'Conceptual Design',
    description: 'We begin with an in-depth consultation to capture your vision and create a unique, visionary concept that integrates modern aesthetics with functionality.'
  },
  // Add additional service details for other service IDs...
};

// Function to open the modal with the relevant details
function openModal(serviceId) {
  const details = serviceDetails[serviceId];
  if (details) {
    document.getElementById('modalContent').innerHTML = `
      <h3>${details.title}</h3>
      <p>${details.description}</p>
    `;
    document.getElementById('modalOverlay').classList.add('active');
  }
}

// Function to close the modal
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
}

// Event listeners for service cards
document.querySelectorAll('.service-card').forEach(card => {
  card.addEventListener('click', function() {
    const serviceId = this.getAttribute('data-service-id');
    openModal(serviceId);
  });
});

// Event listener for closing the modal
document.getElementById('modalClose').addEventListener('click', closeModal);

// Close modal if clicking outside the modal container
document.getElementById('modalOverlay').addEventListener('click', function(e) {
  if(e.target === this) {
    closeModal();
  }
});


  </script>

</body>
</html>
