  <!-- Header -->
  <div class="header">
    <div class="logo">
      <img src="images/ages-logo.jpg" alt="Logo" /> <!-- Replace with your logo -->
    </div>
    <nav class="nav-menu" id="nav-menu">
      <a href="index.php">Home</a>
      <a href="services.php">Services</a>
      <a href="#">Portfolio</a>
      <a href="#">Resume</a>
      <a href="#" class="contact-btn" onclick="showContact()">Contact</a>
    </nav>
    <div class="menu-icon" onclick="toggleMenu()">☰</div>
</div>

<script>
   function toggleMenu() {
      document.getElementById("nav-menu").classList.toggle("active");
    }
</script>